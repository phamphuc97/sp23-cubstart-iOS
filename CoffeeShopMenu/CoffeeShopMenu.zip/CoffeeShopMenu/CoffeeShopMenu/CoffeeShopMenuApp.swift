//
//  CoffeeShopMenuApp.swift
//  CoffeeShopMenu
//
//  Created by Enya Do on 2/22/23.
//

import SwiftUI

@main
struct CoffeeShopMenuApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
